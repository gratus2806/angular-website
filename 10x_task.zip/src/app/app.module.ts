
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from "./shared/shared.module";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { ContentLayoutComponent } from "./layouts/content/content-layout.component";
import { FullLayoutComponent } from "./layouts/full/full-layout.component";

import { AuthService } from './shared/auth/auth.service';
import { AuthGuardService } from './shared/auth/auth-guard.service';
import { ShareService } from './shared/service/share.service';
import { ApiService } from './shared/service/api.service';
// import { NotifyService } from './shared/service/notify.service';
import { NotifierModule } from 'angular-notifier';
import { UtilService } from './shared/service/util.service';
import * as $ from 'jquery';

import {HashLocationStrategy, Location, LocationStrategy} from '@angular/common';

import { ToastrModule } from 'ngx-toastr'; 

@NgModule({
    declarations: [
        AppComponent,
        FullLayoutComponent,
        ContentLayoutComponent
    ],
    imports: [
        BrowserModule,
        HttpModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        NotifierModule,
        SharedModule,
        NgbModule.forRoot(),
        ToastrModule.forRoot() // ToastrModule added
    ],
    providers: [
        AuthService,
        AuthGuardService,
        ShareService,
        ApiService,
        // NotifyService,
        UtilService,
    [Location, {provide: LocationStrategy, useClass: HashLocationStrategy}],
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }