import { Component } from '@angular/core';

import { JwtHelper} from 'angular2-jwt';
import { ShareService } from './shared/service/share.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})
export class AppComponent {
	jwtHelper: JwtHelper = new JwtHelper();

	constructor(private shareService: ShareService){
		let token = localStorage.getItem('x-auth-token');
		if(typeof token != 'undefined' && token != null){
			if(!this.jwtHelper.isTokenExpired(token)){
				let decode_user = this.jwtHelper.decodeToken(token);
				this.shareService.setCurrentUser(decode_user);
			}
		}
	}
}