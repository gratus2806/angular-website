import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomValidators } from 'ng2-validation';

import { AuthService } from '../shared/auth/auth.service';
import { ROLES } from '../shared/service/share.service';
// import { NotifyerService } from '../shared/service/notifyer.service';

import swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  	register: FormGroup;
	error: string;
	errors: any;
	isProcessing: boolean = false;
	formTouched: boolean = false;
	confirm: boolean = false;
	constructor(
			fb: FormBuilder,
			private authService: AuthService,
			private router: Router,
			// private notifyerService: NotifyerService,
			// private notifier: NotifierService
		) { 
		this.register = fb.group({
			"name": ["CIS", Validators.compose([Validators.required])],
			"fullname": ["Mohit", Validators.compose([Validators.required])],
			"username": ["mohit@gmail.com", Validators.compose([Validators.required,CustomValidators.email])],
			"password": ["123", Validators.required],
			"confirmpwd": ["1234", Validators.required],
			"terms": ["", Validators.required],
		});
		this.errors = {
			"name": "",
			"fullname": "",
			"username": "",
			"password": "",
			"confirmpwd": "",
			"terms": ""
		};
	}	

	ngOnInit() {
	}

	resetErrorMessages(){
		this.errors = {
			"name": "",
			"fullname": "",
			"username": "",
			"password": "",
			"confirmpwd": "",
			"terms": ""
		};
	}
	
	signup(register){

		this.formTouched = true;
		if(register.invalid){
			return false;
		}
		this.resetErrorMessages();

		if((this.register.value.password != this.register.value.confirmpwd))
		{
			this.confirm = true;
			return false;
		}
		else
			this.confirm = false;
		
		this.isProcessing = true;

		this.authService.register(register).then((data) => {
			this.isProcessing = false;
			// let user: any=data;
			swal("Registration Completed !!", "Kindly Login & Enjoy !!", "success")
			this.router.navigateByUrl('/login');
		})
		.catch(error => {
			this.isProcessing = false;
			if(typeof error.errors !== 'undefined')
					this.errors = error.errors;
			else
				swal("Oops", "Something went wrong, Kindly Contact Administrator !!", "error")
		});
	}

}
