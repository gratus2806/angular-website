import { Injectable } from '@angular/core';
import { Http, Headers, Response} from '@angular/http';
import { Router } from '@angular/router';

import { SlimLoadingBarService } from 'ng2-slim-loading-bar';

import { JwtHelper } from 'angular2-jwt';
import { ShareService } from './share.service';

import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';


 // export const endPoint: string = "http://127.0.0.1:8000/api/";
export const endPoint: string = "http://code.10xtask.com/public/api/";

@Injectable({
  providedIn: 'root'
})
export class ApiService {
	jwtHelper: JwtHelper = new JwtHelper();
    //headers: Headers = new Headers();
    constructor(
            public http: Http, 
            // private slimLoader: SlimLoadingBarService, 
            private shareService: ShareService, 
            private router: Router
    ) { }

    get(url){
        // this.slimLoader.start();
        return new Promise((resolve, reject) => {

            // We're using Angular HTTP provider to request the data,
            // then on the response, it'll map the JSON data to a parsed JS object.
            // Next, we process the data and resolve the promise with the new data.
            let headers = new Headers();
            this.setHeaders(headers,"get")
            .then( data => {
                let l_data: any = data;

                return this.http.get(endPoint+url,{headers: l_data.headers})
                .map(this.extractData)
                .subscribe(data=> {
                    // this.slimLoader.complete();
                    resolve(data)
                },error=> {
                    // this.slimLoader.complete();
                    //Check for status code if it is 401 or 403, then redirect to login page.
                    if(error.status == 401 || error.status == 403 || error.status == 400){
                        localStorage.removeItem('x-auth-token');
                        this.shareService.setCurrentUser(false);
                        this.router.navigateByUrl('/login');
                    }
                    reject(error)
                })
            });
        });
    }
    delete(url){
        // this.slimLoader.start();
        return new Promise((resolve, reject) => {

            // We're using Angular HTTP provider to request the data,
            // then on the response, it'll map the JSON data to a parsed JS object.
            // Next, we process the data and resolve the promise with the new data.
            let headers = new Headers();
            this.setHeaders(headers,"get")
            .then( data => {
                let l_data: any = data;

                return this.http.delete(endPoint+url,{headers: l_data.headers})
                .map(this.extractData)
                .subscribe(data=> {
                    // this.slimLoader.complete();
                    resolve(data)
                },error=> {
                    // this.slimLoader.complete();
                    //Check for status code if it is 401 or 403, then redirect to login page.
                    if(error.status == 401 || error.status == 403 || error.status == 400){
                        localStorage.removeItem('x-auth-token');
                        this.shareService.setCurrentUser(false);
                        this.router.navigateByUrl('/login');
                    }
                    reject(error)
                })
            });
        });
    }
    post(url,postdata){
        // this.slimLoader.start();
        return new Promise((resolve,reject) => {
            // We're using Angular HTTP provider to request the data,
            // then on the response, it'll map the JSON data to a parsed JS object.
            // Next, we process the data and resolve the promise with the new data.
            let headers = new Headers();
            let doNotCheckForTokenExpiry = false;
            if(url == 'auth/login')
                doNotCheckForTokenExpiry = true;
            this.setHeaders(headers,"post", doNotCheckForTokenExpiry)
            .then( data => {
                let l_data: any = data;
                let postdata_string = this.objectToParams(postdata);

                this.http.post(endPoint+url, postdata_string,{
                    headers: l_data.headers
                })
                /*.map(res => res.json())*/
                .subscribe(data => {
                    // we've got back the raw data

                    data = data.json();
                    // this.slimLoader.complete();
                    resolve(data);

                },(error => {
                    // this.slimLoader.complete();
                    if(error.status == 401 || error.status == 403 || error.status == 400 ){
                        localStorage.removeItem('x-auth-token');
                        this.shareService.setCurrentUser(false);
                        this.router.navigateByUrl('/login');
                    }
                    reject(error.json());
                }));

            });
        })
    }
    put(url,postdata){
        // this.slimLoader.start();
        return new Promise((resolve,reject) => {
            // We're using Angular HTTP provider to request the data,
            // then on the response, it'll map the JSON data to a parsed JS object.
            // Next, we process the data and resolve the promise with the new data.
            let headers = new Headers();
            let doNotCheckForTokenExpiry = false;
            if(url == 'auth/login')
                doNotCheckForTokenExpiry = true;
            this.setHeaders(headers,"post", doNotCheckForTokenExpiry)
            .then( data => {
                let l_data: any = data;
                let postdata_string = this.objectToParams(postdata);

                this.http.put(endPoint+url, postdata_string,{
                    headers: l_data.headers
                })
                /*.map(res => res.json())*/
                .subscribe(data => {
                    // we've got back the raw data

                    data = data.json();
                    // this.slimLoader.complete();
                    resolve(data);

                },(error => {
                    
                    // this.slimLoader.complete();
                    if(error.status == 401 || error.status == 403 || error.status == 400 ){
                        localStorage.removeItem('x-auth-token');
                        this.shareService.setCurrentUser(false);
                        this.router.navigateByUrl('/login');
                    }
                    reject(error.json());
                }));

            });
        })
    }


    postWithFile(url,postdata,files){
        // this.slimLoader.start();
        return new Promise((resolve,reject) => {
            // We're using Angular HTTP provider to request the data,
            // then on the response, it'll map the JSON data to a parsed JS object.
            // Next, we process the data and resolve the promise with the new data.
            let headers = new Headers();
            let formData:FormData = new FormData();
            let doNotCheckForTokenExpiry = false;
            if(url == 'auth/login')
                doNotCheckForTokenExpiry = true;
            this.setHeaders(headers,"", doNotCheckForTokenExpiry)
            .then( data => {
                let l_data: any = data;
                if(files.file !=="" && files.file !== undefined && files.file !==null){
                    formData.append(files.param, files.file, files.file.name);
                }
                
                // For multiple files
                // for (let i = 0; i < files.length; i++) {
                    //     formData.append(`files[]`, files[i], files[i].name);
                    // }

                    if(postdata !=="" && postdata !== undefined && postdata !==null){
                        for (var property in postdata) {
                            if (postdata.hasOwnProperty(property)) {
                                formData.append(property, postdata[property]);
                            }
                        }
                    }

                    this.http.post(endPoint+url, formData,{
                        headers: l_data.headers
                    })
                    /*.map(res => res.json())*/
                    .subscribe(data => {
                        // we've got back the raw data

                        data = data.json();
                        // this.slimLoader.complete();

                        resolve(data);

                    },(error => {
                        // this.slimLoader.complete();
                        if(error.status == 401 || error.status == 403 || error.status == 400 ){
                            localStorage.removeItem('x-auth-token');
                            this.shareService.setCurrentUser(false);
                            this.router.navigateByUrl('/login');
                        }
                        reject(error.json());
                    }));

                });
            

            
            
        })
    }



    private isMobile(){
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body || { };
    }

    private setHeaders(headers,type: string, doNotCheckForTokenExpiry:boolean = false){
        return new Promise((resolve, reject) => {
            if(type === 'post')
                headers.append('Content-Type', 'application/x-www-form-urlencoded');

            let userToken: any = localStorage.getItem('x-auth-token');

            //Authorization: Bearer <token>
            if((!doNotCheckForTokenExpiry) && userToken !== false && userToken !== null){

                if(this.jwtHelper.isTokenExpired(userToken)) 
                {

                    return this.refreshToken(userToken)
                    .then(data => {
                        let l_data:any = data;
                        headers.append('Authorization', 'Bearer '+ l_data.token);
                        resolve({headers: headers});
                    })
                    .catch( err => resolve(({headers: headers}))) // OnPurpose putting it as resolved, so that further request can be proceeded
                    ;
                }
            }
            userToken = localStorage.getItem('x-auth-token');

            if(userToken !== false && userToken !== null) headers.append('Authorization', 'Bearer '+ userToken);


            resolve({headers: headers});               
            

        })
        
    }

     /**
    * Converts an object to a parametrised string.
    * @param object
    * @returns {string}
    */
    public objectToParams(object): string {
        return Object.keys(object).map((key) => this.isJsObject(object[key]) ?
            this.subObjectToParams(encodeURIComponent(key), object[key]) :
            `${encodeURIComponent(key)}=${encodeURIComponent(object[key])}`
            ).join('&');
    }
    /**
    * Converts a sub-object to a parametrised string.
    * @param object
    * @returns {string}
    */
    private subObjectToParams(key, object): string {
        return Object.keys(object).map((childKey) => this.isJsObject(object[childKey]) ?
            this.subObjectToParams(`${key}[${encodeURIComponent(childKey)}]`, object[childKey]) :
            `${key}[${encodeURIComponent(childKey)}]=${encodeURIComponent(object[childKey])}`
            ).join('&');
    }
    
    private isJsObject(obj) {
        return /^\[object (?:object|global|window)\]$/i
        .test(Object.prototype.toString.call(obj));
    }

    private refreshToken(userToken){
        return new Promise((resolve, reject) => {
            let l_data: any;
            let headers = new Headers();
            headers.append('Authorization', 'Bearer '+ userToken);

            return this.http.get(endPoint+'auth/refresh_token', {headers: headers})
            .map(this.extractData)
            .subscribe(data=> {
                l_data = data;
                let token = l_data.token;
                let decode_user = this.jwtHelper.decodeToken(token);
                this.shareService.setCurrentUser(decode_user);
                localStorage.setItem('x-auth-token',token);
                resolve(data);
            },error=> {
                localStorage.removeItem('x-auth-token');
                this.shareService.setCurrentUser(false);
                reject(error)
            });


        })
    }
}
