import { Injectable } from '@angular/core';
import { PlatformLocation } from '@angular/common'

export const ROLES = {
	GUEST : 0,
	SYSTEM : 1,
	ADMIN : 2,
	GENERAL_MANAGER : 3,
	DEPARTMENT_HEAD : 4,
	EMPLOYEE : 5,
	OFFICE_BOY : 6	
}

@Injectable({
  providedIn: 'root'
})
export class ShareService {
	data = {};
	constructor(
			location: PlatformLocation
	)  {}

	set(key,value){
		this.data[key] = value;
	}
	get(key){
		return this.data[key];
	}
	getApiPath(){
		return "http://127.0.0.1:8000/api/";
		// return "http://code.10xtask.com/public/api/";
	}
	setCurrentUser(currentUser){
		this.set("__currentUser__",currentUser);
	}
	getCurrentUser(){
		return this.get("__currentUser__") || false;
	}
	isLoggedIn(){
		return !!this.getCurrentUser();
	}
}
