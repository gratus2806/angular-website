import { TestBed } from '@angular/core/testing';

import { NotifyerService } from './notifyer.service';

describe('NotifyerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NotifyerService = TestBed.get(NotifyerService);
    expect(service).toBeTruthy();
  });
});
