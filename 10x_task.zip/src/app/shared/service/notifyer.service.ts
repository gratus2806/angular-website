import { Injectable } from '@angular/core';
import { NotifierService } from 'angular-notifier';

@Injectable({
  providedIn: 'root'
})
export class NotifyerService {

	notifier: NotifierService;

	constructor( notifier: NotifierService ) {
			this.notifier = notifier;
	}

	public show( type: string, message: string ): void {
		this.notifier.notify( type, message );
	}
}
