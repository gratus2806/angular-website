import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UtilService {

  constructor() { }
  convertToDateObject(date: string) {
		let d:any = date.split('-');
		return {
			date: {year: parseInt(d[0]), month:parseInt(d[1]), day: parseInt(d[2])},
			formatted: date
		}
	}
}
