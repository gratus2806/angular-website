import { Component, AfterViewChecked } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';
// import { NotifyService } from '../service/notify.service';
import { ShareService } from '../service/share.service';

@Component({
    selector: 'app-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.scss']
})

export class NavbarComponent implements AfterViewChecked{

    toggleClass = 'ft-maximize';
    placement = 'bottom-right'
    public isCollapsed = true;
    public user: any;
    public show: any;
    public days: any;

    constructor(
    private authService: AuthService,
    private router: Router,
    private shareService: ShareService,
    // private notifyService: NotifyService
    ){}

    ngOnInit(): void {
        this.user = this.shareService.getCurrentUser();
        let today = new Date();
        let exp = new Date(this.user.expiry_date);
        var timeDiff = Math.abs(exp.getTime() - today.getTime());
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
        if(diffDays <= 30)
        {
            this.show = 1;
            this.days = diffDays;
        }
    }

    ngAfterViewChecked() {

        setTimeout(() => {
            var wrapperDiv = document.getElementsByClassName("wrapper")[0];
            var dir = wrapperDiv.getAttribute("dir");
            if (dir === 'rtl') {
                this.placement = 'bottom-left';
            }
            else if (dir === 'ltr') {
                this.placement = 'bottom-right';
            }
        }, 3000);


    }

    ToggleClass() {
        if (this.toggleClass === 'ft-maximize') {
            this.toggleClass = 'ft-minimize';
        }
        else
            this.toggleClass = 'ft-maximize'
    }


    logout() {
        this.authService.logout()
        .then( data => {
            let l_data: any = data;
            /*this.notifyService.show({
                    title: "Success",
                    message: l_data.message
            });*/
            this.router.navigateByUrl("/login")
        } 
        )
        .catch((error) => {
            /*this.notifyService.show({
                    title: "Success",
                    message: error.message
            });*/
            this.router.navigateByUrl("/login")
        }
        )
    }
}
