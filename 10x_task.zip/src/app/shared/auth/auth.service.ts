import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { JwtHelper} from 'angular2-jwt';

import { ApiService } from '../service/api.service';
import { ShareService } from '../service/share.service';

@Injectable()
export class AuthService {
    token: string;
    jwtHelper: JwtHelper = new JwtHelper();

    constructor(
        private shareService: ShareService,
        private apiService: ApiService
     ) {}

    login(user){
      return new Promise((resolve, reject) => {
        let l_data: any;
        this.apiService.post("auth/login",user.value)
        .then((status) => {
          l_data = status;
          if(l_data.status == 'success')
          {
              resolve(this.updateToken(l_data.token));
          }
          else
          {
              reject(l_data);
          }
        })
        .catch((error) => {
          reject(error);
        });
      });
    }

    getToken() {    
        return this.token;
    }

    isAuthenticated() {
        // here you can check if user is authenticated or not through his token 
        return true;
    }

    logout(){
      // this.token = null;
        return new Promise((resolve, reject) => {
          let l_data: any;
          this.apiService.get("auth/logout")
          .then((data) => {
            localStorage.removeItem('x-auth-token');
            this.shareService.setCurrentUser(false);
            resolve(data);
          })
          .catch(( error )=> {
            localStorage.removeItem('x-auth-token');
            this.shareService.setCurrentUser(false);
            reject(error)
          });

        });
  }

  register(register){
        return new Promise((resolve, reject) => {
          let l_data: any;
          this.apiService.post("auth/signup",register.value)
          .then((data) => {
            l_data = data;
            resolve(l_data);
          })
          .catch((error) => {
            reject(error.error);
          });
        });
  }

  updateToken(token){
        let decode_user = this.jwtHelper.decodeToken(token);
        this.shareService.setCurrentUser(decode_user);
        localStorage.setItem('x-auth-token',token);
        return decode_user;
  }
}
