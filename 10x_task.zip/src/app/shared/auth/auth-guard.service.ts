import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
// import { AuthService } from './auth.service';

import { ShareService } from '../service/share.service';
import { ROLES } from '../service/share.service';


@Injectable()
export class AuthGuardService implements CanActivate {

  /*constructor(private authService: AuthService) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.authService.isAuthenticated();
  }*/
	  constructor(private shareService: ShareService, private router: Router) { }
		canActivate(route: ActivatedRouteSnapshot,state: RouterStateSnapshot) {
			
			let roles = route.data["roles"] as Array<number>;
			let user = this.shareService.getCurrentUser();
			/*if( roles.indexOf(ROLES.GUEST) != -1){
				if(this.shareService.isLoggedIn()){
					this.router.navigateByUrl('/dashboard');
					return false;
				}
				else{
					return true;
				}
			}*/
			/*if(this.shareService.isLoggedIn()){
				return true;
			}
			else{
				this.router.navigateByUrl('/login');
			}*/

			if( roles.indexOf(ROLES.GUEST) != -1){
				if(this.shareService.isLoggedIn()){
					this.router.navigateByUrl('/dashboard');
					return false;
					/*localStorage.removeItem('x-auth-token');
					this.shareService.setCurrentUser(false);*/
					// return true;
				}
				else{
					return true;
				}
			}
			if(this.shareService.isLoggedIn() && (roles.indexOf(user.user_level) != -1 )){
				return true;
			}
			else{
				this.router.navigateByUrl('/login');
			}

			// return true;
		}
}
