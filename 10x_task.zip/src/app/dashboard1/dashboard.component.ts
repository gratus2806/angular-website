import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomValidators } from 'ng2-validation';

import { ApiService } from '../shared/service/api.service';
import { NotifyService } from '../shared/service/notify.service';

import swal from 'sweetalert2';
// custom;


@Component({
	templateUrl: 'dashboard.component.html'
})

export class DashboardComponent implements OnInit {
	active: string = 'today';
	total_task: any = "0";
	completed_task: any = "0";
	pending_task: any = "0";
	incomplete_task: any = "0";
	dashboard: FormGroup;
	temp_data:any;
	data:any;
	todayTask:any;
	overdueTask:any;
	futureTask:any;
	paginationData:any = {
		total: 0,
		from: 0,
		to: 0,
		prev_page_url: null,
		next_page_url: null,
		per_page: 20,
		current_page: 1
	};
	search: any = {
		priority: "",
		client_name: "",
		task: "",
		comments: "",
		work_types: "",
		employee: ""
	}

	constructor(
		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		private notifyService: NotifyService,
		) {

	}


	ngOnInit() {
			/*this.temp_data = this.apiService.get('admin/dashboard/all_data')
			.then(	dashboard =>	{
				let l_data:any = dashboard;
				this.data = l_data.data;
				this.total_task = this.data.total_task;
				this.completed_task = this.data.completed_task;
				this.pending_task = this.data.pending_task;
				this.incomplete_task = this.data.incomplete_task;
				this.todayTask = this.data.today_task;
				this.overdueTask = this.data.overdue_task;
				this.futureTask = this.data.future_task;
			}
			);*/

		this.getDashboard();
	}

	getReset()
	{
		this.search['priority']='';
		this.search['client_name']='';
		this.search['task']='';
		this.search['comments']='';
		this.search['work_types']='';
		this.search['employee']='';

		this.getDashboard();
	}

	getDashboard(){
		this.temp_data = this.apiService.get('admin/dashboard/all_data?search[priority]='+this.search.priority+
			'&search[client_name]='+this.search.client_name+
			'&search[task]='+this.search.task+
			'&search[comments]='+this.search.comments+
			'&search[work_types]='+this.search.work_types+
			'&search[employee]='+this.search.employee
		).then(	dashboard =>	{
				let l_data:any = dashboard;
				this.data = l_data.data;
				this.total_task = this.data.total_task;
				this.completed_task = this.data.completed_task;
				this.pending_task = this.data.pending_task;
				this.incomplete_task = this.data.incomplete_task;
				this.todayTask = this.data.today_task;
				this.overdueTask = this.data.overdue_task;
				this.futureTask = this.data.future_task;
			}
			);
	}

	task_done(id){
		swal({
			title: 'Are you sure',
			text: "You want to change the Status ??",
			type: 'question',
			showCancelButton: true,
			confirmButtonText: 'Yes'
		}).then( () => {
						this.apiService.get('admin/task_done/'+id)
						.then(res => {
							let result : any = res;
							if(result.status == 'success')
							{
								this.notifyService.show({
									title: 'Success',
									message: result.message
								});
								this.getDashboard();
							}
							else{
									this.notifyService.show({
										title: 'Error',
										type : 'error',
										message: result.message
									});
							}
						})
			})
	}
	
} // end of class DashboardComponent
