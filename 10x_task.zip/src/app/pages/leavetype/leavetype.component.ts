import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomValidators } from 'ng2-validation';

import swal from 'sweetalert2'

import { ApiService } from '../../shared/service/api.service';
import { NotifyService } from '../../shared/service/notify.service';

@Component({
  selector: 'app-leavetype',
  templateUrl: './leavetype.component.html',
  styleUrls: ['./leavetype.component.scss']
})
export class LeavetypeComponent implements OnInit {

  	leavetype:any;
	paginationData:any = {
		total: 0,
		from: 0,
		to: 0,
		prev_page_url: null,
		next_page_url: null,
		per_page: 20,
		current_page: 1
	};
	order: string = 'name';
	search: any = {
		name: ""
	};
	constructor(
			private apiService: ApiService,
			private notifyService: NotifyService,
	) {}

	ngOnInit() {
		this.getData();
	}

	getReset()
	{
		this.search['name']='';
		this.getData();
	}

	getData(page = 1){
		this.apiService.get('admin/leavetype?page='+page+
						'&search[name]='+this.search.name

		).then( data => {
			let l_data:any = data;
			l_data = l_data.data;
			this.leavetype = l_data.data;
			this.paginationData = {
				total: l_data.total,
				from: l_data.from,
				to: l_data.to,
				prev_page_url: l_data.prev_page_url,
				next_page_url: l_data.next_page_url,
				per_page: l_data.per_page,
				current_page: l_data.current_page,
				id: 'leave_type_list'
			}
		})
	}
	removeLeaveType(id){
		swal({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then( () => {
			this.apiService.delete('admin/leavetype/'+id)
			.then(data => {
				this.notifyService.show({
					title: 'Success',
					message: 'Successfully deleted'
				});
				this.getData(this.paginationData.current_page);
			})
		})
	}

}
