import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { NgxPaginationModule } from 'ngx-pagination';

import { LeavetypeRoutingModule } from './leavetype-routing.module';
import { LeavetypeComponent } from './leavetype.component';

@NgModule({
  imports: [
    CommonModule,
    LeavetypeRoutingModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [LeavetypeComponent]
})
export class LeavetypeModule { }
