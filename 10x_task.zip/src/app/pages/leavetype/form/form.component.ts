import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { ApiService } from '../../../shared/service/api.service';
// import { NotifyService } from '../../../shared/service/notify.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

  	id: any = "new";
	categories: any;
	leavetype: FormGroup;
	formTouched: boolean = false;
	isProcessing: boolean = false;
	errors: any;
	constructor(
		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		// private notifyService: NotifyService
		) { 

		this.leavetype = fb.group({
			"id": [this.id, Validators.required],
			"name": [""],
		})
		this.resetErrorMessages();

	}
	resetErrorMessages(){
		this.errors = {
			"name": [""]
		}
	}

	cancel(){
		this.router.navigateByUrl('/leavetype');
	}
	
	ngOnInit() {
		//this.apiService.
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
				this.getRecord(this.id);
			}
		});
	}

	getRecord(id:any){
		this.apiService.get("admin/leavetype/"+id)
		.then(data => {
			let l_data: any = data;
			console.log(l_data);
			this.leavetype.patchValue(l_data.leave_type);
		})
	}
	
	addOrUpdate(leavetype){
		this.formTouched = true;
		if(leavetype.invalid){
			console.log(leavetype.value);
			return false;
		}
		this.resetErrorMessages();
		this.isProcessing = true;
		if(leavetype.value.id == "new"){
			//post request
			this.apiService.post("admin/leavetype",leavetype.value)
			.then( data => {
				//success
				this.isProcessing = false;
				alert('Leave Type added successfully');
				// this.notifyService.show({title: 'Success', message: 'Leave Type added successfully'});
				this.router.navigateByUrl('/leavetype');
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
			})
		}else{
			//Put request

			this.apiService.put("admin/leavetype/"+leavetype.value.id,leavetype.value)
			.then( data => {
				//success
				this.isProcessing = false;
				alert('Leave Type updated successfully');
				// this.notifyService.show({title: 'Success', message: 'Leave Type updated successfully'});
				this.router.navigateByUrl('/leavetype');
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
				
			})
		}
	}

}
