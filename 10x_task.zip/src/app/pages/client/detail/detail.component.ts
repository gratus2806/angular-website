import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import swal from 'sweetalert2'

import { ApiService } from '../../../shared/service/api.service';
// import { NotifyService } from '../../../shared/service/notify.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})

export class DetailComponent implements OnInit {
	
	id: any = "new";
	client_id: any = "new";
  	data:any = {
  		salutation: '',
  		name: ''
  	};
  	task:any;
  	task_data: any = "";
  	attachment_data: any = "";
	paginationData:any = {
		total: 0,
		from: 0,
		to: 0,
		prev_page_url: null, 
		next_page_url: null,
		per_page: 20,
		current_page: 1
	};
	search: any = {
	}
	constructor(
		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		// private notifyService: NotifyService
		) { 
	}

	ngOnInit() {
		// this.getData();
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
				this.getData(this.id);
				this.getTasks();
				// this.getAttachments();
			}
		});
	}

	getData(id){
		this.apiService.get('admin/clients/'+id)
		.then( data => {
			let l_data:any = data;
			if(l_data.status == 'success')
			{
				this.data = l_data.data;
			}
			else
			{
				/*this.notifyService.show({
					title: 'Error', message: l_data.message}, 
				'error');*/
				alert(l_data.message);
			}
		})
	}

	getTasks(page = 1){
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
			}
		});
		this.apiService.get('admin/client_wise_task/'+this.id+'?page='+page)
		.then( task_data => {
			let l_data:any = task_data;
			if(l_data.status == 'success')
			{
				l_data = l_data.data;
				this.task_data = l_data.data;
				this.paginationData = {
					total: l_data.total,
					from: l_data.from,
					to: l_data.to,
					prev_page_url: l_data.prev_page_url,
					next_page_url: l_data.next_page_url,
					per_page: l_data.per_page,
					current_page: l_data.current_page,
					id: 'get_task_list'
				}
			}
			else
			{
				/*this.notifyService.show({
					title: 'Error', message: l_data.message}, 
				'error');*/
				alert(l_data.message);
			}
		})
	}

	/*
	getAttachments(page = 1){
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
			}
		});
		this.apiService.get('admin/attachment_by_user/'+this.id+'?page='+page)
		.then( attachment_data => {
			let l_data:any = attachment_data;
			this.attachment_data = l_data.data;
			this.paginationData = {
				total: l_data.total,
				from: l_data.from,
				to: l_data.to,
				prev_page_url: l_data.prev_page_url,
				next_page_url: l_data.next_page_url,
				per_page: l_data.per_page,
				current_page: l_data.current_page,
				id: 'get_list'
			}
		})
	}
	
	removeData(id, client_id){
		swal({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then( () => {
			this.apiService.delete('admin/attachment/'+id)
			.then(data => {
				this.notifyService.show({
					title: 'Success',
					message: 'Successfully deleted'
				});
				this.getAttachments();
			})
		})
	}
	*/
	
}
