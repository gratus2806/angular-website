import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomValidators } from 'ng2-validation';

import swal from 'sweetalert2'

import { ApiService } from '../../shared/service/api.service';
import { NotifyService } from '../../shared/service/notify.service';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss']
})
export class ClientComponent implements OnInit {

  data:any;
	paginationData:any = {
		total: 0,
		from: 0,
		to: 0,
		prev_page_url: null,
		next_page_url: null,
		per_page: 20,
		current_page: 1
	};
	search: any = {
		type: "",
		code: "",
		name: "",
		mobile: "",
		company_name: "",
		email_id: "",
		comments: ""
	}
	constructor(
			private apiService: ApiService,
			private router: Router,
			private notifyService: NotifyService,
	) {}

	ngOnInit() {
		this.getData();
	}

	getReset()
	{
		this.search['type']='';
		this.search['code']='';
		this.search['name']='';
		this.search['mobile']='';
		this.search['company_name']='';
		this.search['email_id']='';
		this.search['comments']='';
		this.getData();
	}

	getData(page = 1){
		this.apiService.get(
			'admin/clients?page='+page+
			'&search[type]='+this.search.type+
			'&search[code]='+this.search.code+
			'&search[name]='+this.search.name+
			'&search[mobile]='+this.search.mobile+
			'&search[company_name]='+this.search.company_name+
			'&search[email_id]='+this.search.email_id+
			'&search[comments]='+this.search.comments

		).then( data => {
			let l_data:any = data;

			if(l_data.status == 'success')
			{
				l_data = l_data.data;
				this.data = l_data.data;
				this.paginationData = {
					total: l_data.total,
					from: l_data.from,
					to: l_data.to,
					prev_page_url: l_data.prev_page_url,
					next_page_url: l_data.next_page_url,
					per_page: l_data.per_page,
					current_page: l_data.current_page,
					id: 'get_list'
				}
			}
			else
			{
				this.notifyService.show({title: 'Error', message: l_data.message}, 'error');
			}
			
		})
	}

	removeData(id){
		swal({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then( () => {
			this.apiService.delete('admin/clients/'+id)
			.then(data => {
				this.notifyService.show({
					title: 'Success',
					message: 'Successfully deleted'
				});
				this.getData(this.paginationData.current_page);
			})
		})
	}

}
