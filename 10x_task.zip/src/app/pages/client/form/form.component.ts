import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import {IMyDpOptions, IMyInputFieldChanged} from 'mydatepicker';
import {INgxMyDpOptions, IMyDateModel} from 'ngx-mydatepicker';

import { ApiService } from '../../../shared/service/api.service';
// import { NotifyService } from '../../../shared/service/notify.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

	public myDatePickerOptions: IMyDpOptions = {
				todayBtnTxt: 'Today',
				dateFormat: 'yyyy-mm-dd',
				firstDayOfWeek: 'mo',
				sunHighlight: true,
				openSelectorOnInputClick: true,
				inline: false,
				editableDateField: false
    };
    myOptions: INgxMyDpOptions = {
      todayBtnTxt: 'Today',
      dateFormat: 'yyyy-mm-dd',
      firstDayOfWeek: 'mo',
      sunHighlight: true,
  };

  	id: any = "new";
	type: any;
	client: FormGroup;
	formTouched: boolean = false;
	isProcessing: boolean = false;
	errors: any;
	numbers: any;
	constructor(
		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		// private notifyService: NotifyService
		) { 


		this.client = fb.group({
			"id": [this.id, Validators.required],
			"salutation": ["Mr.", Validators.required],
			"name": ["", Validators.required],
			"company_name": [""],
			"code": [""],
			"mobile": [""],
			"landline": [""],
			"dobr": [""],
			"email_id": [""],
			"gender": ["M", Validators.required],
			"type": ["0", Validators.required],
			"aadhar_no": [""],
			"pan_no": [""],
			"address1": [""],
			"address2": [""],
			"address3": [""],
			"city": [""],
			"pincode": [""],
			"comments": [""],
		})
		this.resetErrorMessages();

		this.numbers = Array(31).fill(1).map((x,i)=>i); // [0,1,2,3,4]

	}

	resetErrorMessages(){
		this.errors = {
			"salutation": [""],
			"code": [""],
			"name": [""],
			"company_name": [""],
			"mobile": [""],
			"landline": [""],
			"dobr": [""],
			"email_id": [""],
			"gender": [""],
			"type": [""],
			"aadhar_no": [""],
			"pan_no": [""],
			"address1": [""],
			"address2": [""],
			"address3": [""],
			"city": [""],
			"pincode": [""],
			"comments": [""],
		}
	}

	ngOnInit() {
		//this.apiService.
		this.getType();
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
				this.getData(this.id);
			}
		});
	}

	cancel(){
		this.router.navigateByUrl('/clients');
	}

	getData(id:any){
		this.apiService.get("admin/clients/"+id)
		.then(data => {
			let l_data: any = data;
			if(l_data.status == 'success')
			{
				this.client.patchValue(l_data.data);
				this.client.patchValue({
					dobr:{
						formatted: l_data.data.dobr
					}
				});
			}
			else
			{
				// this.notifyService.show({title: 'Error', message: l_data.message}, 'error');
			}
		})
	}

	getType(){
		// get type code
	}

	addOrUpdate(client){
		this.formTouched = true;
		if(client.invalid){
			// console.log(client.value);
			return false;
		}
		this.resetErrorMessages();
		this.isProcessing = true;

		client.value.dobr = client.value.dobr.formatted;

			//post request
			this.apiService.post("admin/clients",client.value)
			.then( data => {
				let result: any = data;
				if(result.status == 'success')
				{
					this.isProcessing = false;
					// this.notifyService.show({title: 'Success', message: result.message});
					this.router.navigateByUrl('/clients');
				}
				else
				{
					this.isProcessing = false;
					// this.notifyService.show({title: 'Error', message: result.message}, 'error');
				}
			})
	}

}
