import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ClientComponent } from './client.component';

const routes: Routes = [
{
    path: '',
    component: ClientComponent,
    data: {
      title: 'Client List'
    }
},{
  path: 'form/:id',
  loadChildren: './form/client-form.module#ClientFormModule',
  data: {
      title: 'Form'
    }
},{
  path: 'detail/:id',
  loadChildren: './detail/client-detail.module#ClientDetailModule',
  data: {
      title: 'Attachment'
    }
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientRoutingModule { }
