import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomValidators } from 'ng2-validation';

import swal from 'sweetalert2'

import { ApiService } from '../../shared/service/api.service';
import { NotifyService } from '../../shared/service/notify.service';

@Component({
	selector: 'app-department',
	templateUrl: './department.component.html',
	styleUrls: ['./department.component.scss']
})
export class DepartmentComponent implements OnInit {

	departments:any;
	paginationData:any = {
		total: 0,
		from: 0,
		to: 0,
		prev_page_url: null,
		next_page_url: null,
		per_page: 20,
		current_page: 1
	};
	search: any = {
		name: "",
		status: ""
	}
	constructor(
			private apiService: ApiService, 
			private rrouter: Router,
			private notifyService: NotifyService,
	) {}

	ngOnInit() {
		this.getData();
	}

	getReset()
	{
		this.search['name']='';
		this.search['status']='';
		this.getData();
	}


	getData(page = 1){
		this.apiService.get('admin/department?page='+page+
				'&search[name]='+this.search.name+
				'&search[status]='+this.search.status
		).then( data => {
			let l_data:any = data;
			this.departments = l_data.data;
			this.paginationData = {
				total: l_data.total,
				from: l_data.from,
				to: l_data.to,
				prev_page_url: l_data.prev_page_url,
				next_page_url: l_data.next_page_url,
				per_page: l_data.per_page,
				current_page: l_data.current_page,
				id: 'departments_list'
			}


		})
	}
	removeDepartment(id){
		swal({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then( () => {
			this.apiService.delete('admin/department/'+id)
			.then(data => {
				this.notifyService.show({
					title: 'Success',
					message: 'Successfully deleted'
				});
				this.getData(this.paginationData.current_page);
			})
			
		})
	}

}
