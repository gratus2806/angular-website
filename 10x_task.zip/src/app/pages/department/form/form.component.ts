import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { ApiService } from '../../../shared/service/api.service';
// import { NotifyService } from '../../../shared/service/notify.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
	id: any = "new";
	department: FormGroup;
	formTouched: boolean = false;
	isProcessing: boolean = false;
	errors: any;

  	constructor(
		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		// private notifyService: NotifyService
		) { 

		this.department = fb.group({
			"id": [this.id, Validators.required],
			"name": ["", Validators.required],
			"status": ["1", Validators.required]
		})
		this.resetErrorMessages();

	}
	resetErrorMessages(){
		this.errors = {
			"name": [""],
			"status": [""]
		}
	}

	cancel(){
		this.router.navigateByUrl('/department');
	}

  	ngOnInit() {
		//this.apiService.
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
				this.getDepartment(this.id);
			}
		});
	}

	getDepartment(id:any){
		this.apiService.get("admin/department/"+id)
		.then(data => {
			let l_data: any = data;
			//console.log(l_data);
			this.department.patchValue(l_data.department);
		})
	}

	addOrUpdateDepartment(department){
		this.formTouched = true;
		if(department.invalid){
			console.log(department.value);
			return false;
		}
		this.resetErrorMessages();
		this.isProcessing = true;
		if(department.value.id == "new"){
			//post request
			this.apiService.post("admin/department",department.value)
			.then( data => {
				//success
				this.isProcessing = false;
				// this.notifyService.show({title: 'Success', message: 'Department added successfully'});
				this.router.navigateByUrl('/department');
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
			})
		}else{
			//Put request

			this.apiService.put("admin/department/"+department.value.id,department.value)
			.then( data => {
				//success
				this.isProcessing = false;
				// this.notifyService.show({title: 'Success', message: 'Department updated successfully'});
				this.router.navigateByUrl('/department');
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
				
			})
		}
	}

}
