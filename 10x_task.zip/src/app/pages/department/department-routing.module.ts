import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DepartmentComponent } from './department.component';

const routes: Routes = [
{
    path: '',
    component: DepartmentComponent,
    data: {
      title: 'Department'
    }
},{
	path: 'form/:id',
	loadChildren: './form/department-form.module#DepartmentFormModule',
	data: {
      title: 'Form'
    }
}
]; 

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DepartmentRoutingModule { }
