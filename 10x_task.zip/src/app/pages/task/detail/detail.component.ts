import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import swal from 'sweetalert2'

import { ApiService } from '../../../shared/service/api.service';
// import { NotifyService } from '../../../shared/service/notify.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {

	id: any = "new";
	module_id: any = "new";
  	data:any = {
  		salutation: '',
  		name: ''
  	};
  	attachments_data: any = "";
  	comments_data: any = "";
  	taskcomments: any;
	paginationData:any = {
		total: 0,
		from: 0,
		to: 0,
		prev_page_url: null, 
		next_page_url: null,
		per_page: 20,
		current_page: 1
	};
	search: any = {
	}
	constructor(
		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		// private notifyService: NotifyService
		) { 
	}

	ngOnInit() {
		// this.getData();
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
				this.getData(this.id);
				// this.getAttachments();
			}
		});
	}

	getData(id){
		this.apiService.get('admin/task/'+id)
		.then( data => {
			let l_data:any = data;
			this.data = l_data.data;
			this.comments_data = l_data.comments;
		})
	}

	getAttachments(page = 1){
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
			}
		});
		this.apiService.get('admin/attachment_by_task/'+this.id)
		.then( attachments_data => {
			let l_data:any = attachments_data;
			this.attachments_data = l_data.data;
			this.paginationData = {
				total: l_data.total,
				from: l_data.from,
				to: l_data.to,
				prev_page_url: l_data.prev_page_url,
				next_page_url: l_data.next_page_url,
				per_page: l_data.per_page,
				current_page: l_data.current_page,
				id: 'get_list'
			}
		})
	}

	removeData(id, module_id){
		swal({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then( () => {
			this.apiService.delete('admin/attachment/'+id)
			.then(data => {
				/*this.notifyService.show({
					title: 'Success',
					message: 'Successfully deleted'
				});*/
				this.getAttachments();
			})
		})
	}


	add_comment(task_id){
		console.log(task_id);
		swal({
			title: 'Add Comment',
			input: 'text',
			showCancelButton: true,
			confirmButtonText: 'Submit Comment'
		}).then( (comments) => {

			this.taskcomments = { 
				id :'new',
				task_id : task_id,
				comments : comments

			};

			console.log(this.taskcomments);

			/*this.taskcomments.value.id = 'new';
			this.taskcomments.value.task_id = task_id;
			this.taskcomments.value.comments = comments;*/
			this.apiService.post('admin/task_comments', this.taskcomments)
			.then(data => {
				console.log(data);
				/*this.notifyService.show({
					title: 'Success',
					message: 'Comments Added Succesfully'
				});*/
				this.getData(task_id);
			})



			/*this.notifyService.show({
					title: 'Success',
					message: test
				});*/
		})
		
	}

}
