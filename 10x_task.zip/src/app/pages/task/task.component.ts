import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomValidators } from 'ng2-validation';
// import { FormGroup } from '@angular/forms';

import swal from 'sweetalert2';

import { ApiService } from '../../shared/service/api.service';
import { NotifyService } from '../../shared/service/notify.service';
import { ShareService } from '../../shared/service/share.service';

import { INgxMyDpOptions } from 'ngx-mydatepicker';
import {IMyDrpOptions, IMyDateRangeModel} from 'mydaterangepicker';

import { ExcelService } from '../../shared/service/excel.service';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.scss']
})
export class TaskComponent implements OnInit {

	private myOptions: INgxMyDpOptions = {
		dateFormat: 'dd-mm-yyyy',
		alignSelectorRight: true
	};

	public myDateRangePickerOptions: IMyDrpOptions = {
        // other options...
        dateFormat: 'dd-mm-yyyy',
        editableDateRangeField: false
    };

	// private tasklist: FormGroup;

	count = 0;

  	task:any;
  	limit:any = 25;
  	public user: any;
  	department: any;
	users: any;
	paginationData:any = {
		total: 0,
		from: 0,
		to: 0,
		prev_page_url: null,
		next_page_url: null,
		per_page: 25,
		current_page: 1
	};
	search: any = {
		combine_name: "",
		task: "",
		priority: "",
		deadline_date: "",
		beginDeadlineDate: "",
		endDeadlineDate: "",
		forward_date: "",
		beginForwardDate: "",
		endForwardDate: "",
		department_id: "",
		user_id: "",
		status: "",
		approve: ""
	}

	constructor(
				private apiService: ApiService, 
				private router: Router, 
				private excelService: ExcelService,
				private shareService: ShareService,
				private notifyService: NotifyService
	){
		this.excelService = excelService;
	}

	onChange() {
	    this.count++;
	  }

	ngOnInit() {
		this.getTask();
		this.user = this.shareService.getCurrentUser();
		this.getMasterData();
		// console.log(this.user);
	}

	cancel(){
		this.router.navigateByUrl('/task');
	}

	getReset()
	{
		this.search['combine_name']='';
		this.search['task']='';
		this.search['priority']='';
		this.search['deadline_date']='';
		this.search['beginDeadlineDate']='';
		this.search['endDeadlineDate']='';
		this.search['forward_date']='';
		this.search['beginForwardDate']='';
		this.search['endForwardDate']='';
		this.search['department_id']='';
		this.search['user_id']='';
		this.search['status']='';
		this.search['approve']='';

		this.getTask();
	}

	getTask(page = 1, limit=25){

	limit = this.limit;
		if(this.search.deadline_date != '')
		{
			let beginDeadlineDate: any = this.search.deadline_date['beginDate'];
			this.search.beginDeadlineDate = beginDeadlineDate['year'] + '-' + beginDeadlineDate['month'] + "-" + beginDeadlineDate['day'];

			let endDeadlineDate: any = this.search.deadline_date['endDate'];
			this.search.endDeadlineDate = endDeadlineDate['year'] + '-' + endDeadlineDate['month'] + "-" + endDeadlineDate['day'];
		}

		if(this.search.forward_date !== '')
		{
			let beginForwardDate: any = this.search.forward_date['beginDate'];
			this.search.beginForwardDate = beginForwardDate['year'] + '-' + beginForwardDate['month'] + "-" + beginForwardDate['day'];

			let endForwardDate: any = this.search.forward_date['endDate'];
			this.search.endForwardDate = endForwardDate['year'] + '-' + endForwardDate['month'] + "-" + endForwardDate['day'];
		}

		this.apiService.get('admin/task?page='+page+'&limit='+limit+
			'&search[combine_name]='+this.search.combine_name+
			'&search[task]='+this.search.task+
			'&search[priority]='+this.search.priority+
			'&search[beginDeadlineDate]='+this.search.beginDeadlineDate+
			'&search[endDeadlineDate]='+this.search.endDeadlineDate+
			'&search[beginForwardDate]='+this.search.beginForwardDate+
			'&search[endForwardDate]='+this.search.endForwardDate+
			'&search[department_id]='+this.search.department_id+
			'&search[user_id]='+this.search.user_id+
			'&search[status]='+this.search.status+
			'&search[approve]='+this.search.approve
		).then( data => {
			
			let l_data:any = data;
			l_data = l_data.data;
			if(l_data.length == 0)
			{
				this.notifyService.show({
									title: 'Error',
									message: 'No Records Found'
								}, 'error', 2000);
			}
			this.task = l_data.data;
			this.paginationData = {
				total: l_data.total,
				from: l_data.from,
				to: l_data.to,
				prev_page_url: l_data.prev_page_url,
				next_page_url: l_data.next_page_url,
				per_page: l_data.per_page,
				current_page: l_data.current_page,
				id: 'task_list'
			}
		})
	}

	onDateRangeChangedDeadline($event)
	{
		this.search.deadline_date = $event;
		if(this.search.deadline_date !='')
		{
			if(this.search.deadline_date['formatted'] != '')
			{
				this.getTask(this.paginationData.current_page);
			}
			else
			{
				this.search.deadline_date = '';
				this.search.beginDeadlineDate = '';
				this.search.beginDeadlineDate = '';
				this.getTask(this.paginationData.current_page);
			}
		}
	}

	onDateRangeChangedExtended($event)
	{
		this.search.forward_date = $event;
		if(this.search.forward_date !='')
		{
			if(this.search.forward_date['formatted'] != '')
			{
				this.getTask(this.paginationData.current_page);
			}
			else
			{
				this.search.forward_date = '';
				this.search.beginForwardDate = '';
				this.search.endForwardDate = '';
				this.getTask(this.paginationData.current_page);
			}
		}
	}

	getMasterData(){
		this.apiService.get("admin/mastercall_task_list")
		.then(data => {
			let result: any = data;
			if(result.status == 'success')
			{
				this.department =  result.data.department_fulllist;
			}
		})
	}

	user_by_dept(department_id:any)
	{
		if(department_id != null)
		{
			this.apiService.get("admin/user_by_dept/"+department_id)
			.then(result => {
				let l_data: any = result;
				this.users = l_data.data;
			});
			this.getTask(this.paginationData.current_page);
		}
	}


	task_done_old(id){
		swal({
			title: 'Are you sure',
			text: "You want to change the Status ??",
			type: 'question',
			showCancelButton: true,
			confirmButtonText: 'Yes'
		}).then( () => {
						this.apiService.get('admin/task_done/'+id)
						.then(res => {
							let result : any = res;
							if(result.status == 'success')
							{
								this.notifyService.show({
									title: 'Success',
									message: result.message
								});
								let task_id: any = this.task.find(x => x.id === id);
								let index: any = this.task.indexOf(task_id)
								this.task[index].status = result.data.status;
								// this.getTask(this.paginationData.current_page);
							}
							else{
									this.notifyService.show({
										title: 'Error',
										type : 'error',
										message: result.message
									});
							}
						})
			})
	}

	task_approve_old(id){
		swal({
			title: 'Are you sure',
			text: "You want to Approve ??",
			type: 'question',
			showCancelButton: true,
			confirmButtonText: 'Yes'
		}).then( () => {
						this.apiService.get('admin/task_approve/'+id)
						.then(res => {
							let result : any = res;
							if(result.status == 'success')
							{
								this.notifyService.show({
									title: 'Success',
									message: result.message
								});
								// this.getTask(this.paginationData.current_page);
							}
							else{
									this.notifyService.show({
										title: 'Error',
										type : 'error',
										message: result.message
									});
							}
						})
			})
	}

	task_done(id)
	{
		this.apiService.get('admin/task_done/'+id)
				.then(res => {
					let result : any = res;
					if(result.status == 'success')
					{
						this.notifyService.show({
							title: 'Success',
							message: result.message
						});
						let task_id: any = this.task.find(x => x.id === id);
						let index: any = this.task.indexOf(task_id)
						this.task[index].status = result.data.status;
						// this.getTask(this.paginationData.current_page);
					}
					else{
							this.notifyService.show({
								title: 'Error',
								type : 'error',
								message: result.message
							});
					}
				})

	}

	task_approve(id){
		this.apiService.get('admin/task_approve/'+id)
						.then(res => {
							let result : any = res;
							if(result.status == 'success')
							{
								this.notifyService.show({
									title: 'Success',
									message: result.message
								});
								let task_id: any = this.task.find(x => x.id === id);
								let index: any = this.task.indexOf(task_id)
								this.task[index].approve = result.data.approve;
								// this.getTask(this.paginationData.current_page);
							}
							else{
									this.notifyService.show({
										title: 'Error',
										type : 'error',
										message: result.message
									});
							}
						})
	}



	exportToExcel(limit = 25) {
		limit = this.limit;
		let page = this.paginationData.current_page;
		this.apiService.get('admin/task_export_excel?page='+page+'&limit='+limit+
			'&search[combine_name]='+this.search.combine_name+
			'&search[task]='+this.search.task+
			'&search[priority]='+this.search.priority+
			'&search[beginActionDate]='+this.search.beginActionDate+
			'&search[endActionDate]='+this.search.endActionDate+
			'&search[beginForwardDate]='+this.search.beginForwardDate+
			'&search[endForwardDate]='+this.search.endForwardDate+
			'&search[department_id]='+this.search.department_id+
			'&search[user_id]='+this.search.user_id+
			'&search[status]='+this.search.status
		).then(	data => {
			let l_data:any = data;
			let final_data = l_data.data;
			this.excelService.exportAsExcelFile(final_data, 'tasklist');
		})
	}	

	removeTask(id){
		swal({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then( () => {
			this.apiService.delete('admin/task/'+id)
			.then(data => {
				this.notifyService.show({
					title: 'Success',
					message: 'Successfully deleted'
				});
				this.getTask(this.paginationData.current_page);
			})
		})
	}

}
