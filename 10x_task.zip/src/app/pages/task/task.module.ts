import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { NgxPaginationModule } from 'ngx-pagination';

import { TaskRoutingModule } from './task-routing.module';
import { TaskComponent } from './task.component';

import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { MyDateRangePickerModule } from 'mydaterangepicker';

import { ExcelService } from '../../shared/service/excel.service';

@NgModule({
  imports: [
    CommonModule,
    TaskRoutingModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule,
    MyDateRangePickerModule
  ],
  providers: [ExcelService],
  declarations: [TaskComponent]
})
export class TaskModule { }
