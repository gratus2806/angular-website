import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TaskComponent } from './task.component';

const routes: Routes = [
{
    path: '',
    component: TaskComponent,
    data: {
      title: 'Task List'
    }
},{
	path: 'form/:id',
	loadChildren: './form/task-form.module#TaskFormModule',
	data: {
      title: 'Form' 
    }
},{
  path: 'detail/:id',
  loadChildren: './detail/detail.module#DetailModule',
  data: {
      title: 'Detail'
    }
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TaskRoutingModule { }
