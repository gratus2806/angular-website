import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { MyDatePickerModule } from 'mydatepicker';
import { NgxPaginationModule } from 'ngx-pagination';

import { FormRoutingModule } from './form-routing.module';
import { FormComponent } from './form.component';

// custom
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { HttpModule } from '@angular/http';
// noinspection TypeScriptCheckImport
import { NguiAutoCompleteModule } from '@ngui/auto-complete';


@NgModule({
  imports: [
    CommonModule,
    FormRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MyDatePickerModule,
    HttpModule, FormsModule, NguiAutoCompleteModule
  ],
  declarations: [FormComponent]
})
export class TaskFormModule { } 