import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {INgxMyDpOptions, IMyDateModel} from 'ngx-mydatepicker';

import { ApiService } from '../../../shared/service/api.service';
import { ShareService } from '../../../shared/service/share.service';
import { UtilService } from '../../../shared/service/util.service';
import { NotifyService } from '../../../shared/service/notify.service';

// custom
import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/observable/of';


@Component({
	selector: 'app-form',
	templateUrl: './form.component.html',
	styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {



	myOptions: INgxMyDpOptions = {
      todayBtnTxt: 'Today',
      dateFormat: 'yyyy-mm-dd',
      firstDayOfWeek: 'mo',
      sunHighlight: true,
  };
	

	id: any = "new";
	task: FormGroup;
	clients: any;
	deadline_date1: any;
	deadline_time: any;
	client_name: any;
	data: any;
	department: any;
	users: any;
	client_id: any;
	numbers: any;
	formTouched: boolean = false;
	isProcessing: boolean = false;
	errors: any;

	constructor(
		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		private utilService: UtilService,
		private shareService: ShareService,
		public http: Http,
		// private notifyService: NotifyService
		
		) { 

		this.task = fb.group({
			"id": [this.id, Validators.required],
			"department_id": ["", Validators.required],
			"user_id": ["", Validators.required],
			"client_id": [""],
			"task": ["", Validators.required],
			"deadline_date": ["", Validators.required],
			"deadline_time": [""],
			"forward_date": [""],
			"forward_time": [""],
			"priority": ["High", Validators.required],

			"repetation": ["0", Validators.required],
			"parameter1": [""],
			"parameter2": [""],
			"comments": [""],
		})
		this.resetErrorMessages();
		this.setTodaysDate();

		this.numbers = Array(31).fill(1).map((x,i)=>i); // [0,1,2,3,4]

	}

	observableSource = (keyword: any): Observable<any[]> => {
		    let url: string = 
		      this.shareService.getApiPath()+'admin/search_client/'+keyword;
		      let headers = new Headers();
            let userToken: any = localStorage.getItem('x-auth-token');
            headers.append('Authorization', 'Bearer '+ userToken);
		    if (keyword) {
		      return this.http.get(url,{headers: headers})
		        .map(res => {
		          let json = res.json();
		          return json.data;
		        })
		    } else {
		      return Observable.of([]);
		    }
		  }
		  
	resetErrorMessages(){
		this.errors = {
			"department_id": ["", Validators.required],
			"user_id": ["", Validators.required],
			"client_id": ["", Validators.required],
			"task": ["", Validators.required],
			"deadline_date": ["", Validators.required],
			"deadline_time": ["", Validators.required],
			"forward_date": ["", Validators.required],
			"forward_time": ["", Validators.required],
			"priority": ["", Validators.required],

			"repetation": ["0", Validators.required],
			"parameter1": [""],
			"parameter2": [""],
			"comments": [""],
		}
	}
	
	setTodaysDate(){
		let date = new Date();
		let year: any = date.getFullYear();
		let month: any = date.getMonth() + 1;
		let day: any = date.getDate();
		this.task.patchValue({deadline_date: {
			date: {
				year: year,
				month: month,
				day: day
			},
			formatted: year + '-' + month + '-' + day
			}});
		// console.log(this.task);
		this.task.patchValue({forward_date: {
			date: {
				year: date.getFullYear(),
				month: date.getMonth() + 1,
				day: date.getDate()}
			}});
	}
	ngOnInit() {
		//this.apiService.
		// this.getClients(this.client_id);
		// this.getWorkTypes();
		// this.getUser();
		this.getMasterData();
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
				this.getData(this.id);
			}
		});
	}

	getMasterData(){
		this.apiService.get("admin/mastercall_task_form")
		.then(data => {
			let result: any = data;
			if(result.status == 'success')
			{
				// this.work_types =  result.data.worktypes_list;
				// this.users =  result.data.users_list;
				this.department =  result.data.department_fulllist;
				if(this.id != "new")
					this.users = result.data.users_fulllist;
			}
		})
	}

	user_by_dept(department_id:any)
	{
		console.log(department_id);
		if(department_id != null)
		{
			this.apiService.get("admin/user_by_dept/"+department_id)
			.then(result => {
				let l_data: any = result;
				this.users = l_data.data;
			})
		}
	}

	getClients(client_id:any){
		if(client_id != null)
		{
			this.apiService.get("admin/search_client/"+client_id)
			.then(data => {
				let l_data: any = data;
				this.users = l_data.data;
			})
		}
		else
		{
			this.apiService.get("admin/search_client")
			.then(data => {
				let l_data: any = data;
				this.users = l_data.data;
			})
		}
	}

	getData(id:any){
		this.apiService.get("admin/task/"+id)
		.then(data => { 
			let table_data: any = data;
			let l_data: any = table_data.data;
			// l_data[0].deadline_date = this.utilService.convertToDateObject(l_data[0].deadline_date);
			/*l_data[0].client_id = {
				id: l_data[0].client_id,
				name: l_data[0].client_name
			}*/

			l_data.forward_date = this.utilService.convertToDateObject(l_data.forward_date);
			this.task.patchValue(l_data);
			this.deadline_date1 = l_data.deadline_date1;
			this.deadline_time = l_data.deadline_time;
			this.client_name = l_data.client_name;
			/*this.task.patchValue({
				client_id : ({
					id : l_data.client_id,
					combine_name : l_data.combine_name,
				})
			});*/
			// console.log(this.task);
		})
	}

	cancel(){
		this.router.navigateByUrl('/task');
	}

	addOrUpdate1(task){
		this.formTouched = true;
		if(task.invalid){
			return false;
		}
		this.resetErrorMessages();
		this.isProcessing = true;
		if(task.value.id == "new"){
			//post request
			this.apiService.post("admin/task",task.value)
			.then( data => {
				//success
				this.isProcessing = false;
				// this.notifyService.show({title: 'Success', message: 'Task added successfully'});
				if(task.value.attachment == "Yes"){
					let l_data: any = data;
					let l_data2: any = l_data.task;
					this.router.navigateByUrl('/task/detail/'+l_data2.id);
				}
				else
				{
					this.router.navigateByUrl('/task');	
				}
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
			})
		}else{
			//Put request

			this.apiService.put("admin/task/"+task.value.id,task.value)
			.then( data => {
				//success
				this.isProcessing = false;
				// this.notifyService.show({title: 'Success', message: 'Task updated successfully'});
				// console.log(task.value.attachment);
				if(task.value.attachment == "Yes"){
					this.router.navigateByUrl('/task/detail/'+task.value.id);
				}
				else
				{
					this.router.navigateByUrl('/task');	
				}
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
				
			})
		}
	}


	addOrUpdate(task){
		this.formTouched = true;
		if(task.value.id != 'new')
		{
			if(task.value.comments == '')
			{
				this.errors.comments[0] = 'Please write comments for making changes !!';
				task.invalid = true;
			}
		}

		if(task.invalid){
			return false;
		}
		this.resetErrorMessages();
		this.isProcessing = true;
		
		// console.log(task.value);

		if(task.value.id != 'new')
		{
			task.value.forward_date = task.value.forward_date.formatted;
		}
		else
		{
			task.value.deadline_date = task.value.deadline_date.formatted;
			task.value.client_id = task.value.client_id.id;
		}

		if(!task.value.client_id)
		{
			task.value.client_id = 0;
		}

		

		this.apiService.post("admin/task",task.value)
			.then( res => {

				let result : any = res;
				this.isProcessing = false;
				if(result.success == 'success')
				{
					// this.notifyService.show({title: 'Success', message: result.message});
				}
				else
				{
					// this.notifyService.show({title: 'Success', message: result.message});
					return false;
				}
			})

		this.router.navigateByUrl('/task');
		
		// console.log(task.value);

	}



	getWorkTypes(){
		this.apiService.get("admin/work_types_list")
		.then(data => {
			let l_data: any = data;
			// this.work_types = l_data.data;
		})
	}

	
	getUser(){
		
		this.apiService.get("admin/user_by_dept")
			.then(data => {
				let l_data: any = data;
				this.users = l_data.data;
			})		
	}



}
