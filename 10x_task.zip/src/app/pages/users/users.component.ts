import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import swal from 'sweetalert2'

import { ApiService } from '../../shared/service/api.service';
// import { NotifyService } from '../../shared/service/notify.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {

  	data:any;
	paginationData:any = {
		total: 0,
		from: 0,
		to: 0,
		prev_page_url: null,
		next_page_url: null,
		per_page: 20,
		current_page: 1
	};
	search: any = {
		userlevel_id: "",
		department_id: "",
		fullname: "",
		username: "",
		is_active: ""
	}
	department: any;
	userlevels: any;

	constructor(
			private apiService: ApiService, 
			private router: Router,
			// private notifyService: NotifyService,

	) {}

	ngOnInit() {
		this.getData();
		this.getMasterData();
	}

	getReset()
	{
		this.search['userlevel_id']='';
		this.search['department_id']='';
		this.search['fullname']='';
		this.search['username']='';
		this.search['is_active']='';
		this.getData();
	}

	getData(page = 1){
		this.apiService.get('admin/users?page='+page+
					'&search[userlevel_id]='+this.search.userlevel_id+
					'&search[department_id]='+this.search.department_id+
					'&search[fullname]='+this.search.fullname+
					'&search[username]='+this.search.username+
					'&search[is_active]='+this.search.is_active
		
		).then( data => {
			let l_data:any = data;
			this.data = l_data.data;
			this.paginationData = {
				total: l_data.total,
				from: l_data.from,
				to: l_data.to,
				prev_page_url: l_data.prev_page_url,
				next_page_url: l_data.next_page_url,
				per_page: l_data.per_page,
				current_page: l_data.current_page,
				id: 'get_list'
			}
		})
	}

	getMasterData(){
		this.apiService.get("admin/mastercall_users_list")
		.then(data => {
			let result: any = data;
			if(result.status == 'success')
			{
				this.department =  result.data.department_fulllist;
				this.userlevels =  result.data.userlevels_fulllist;
			}
		})
	}

	removeData(id){
		swal({
			title: 'Are you sure?',
			text: "You won't be able to revert this!",
			type: 'warning',
			showCancelButton: true,
			confirmButtonText: 'Yes, delete it!'
		}).then( () => {
			this.apiService.delete('admin/users/'+id)
			.then(data => {
				/*this.notifyService.show({
					title: 'Success',
					message: 'Successfully deleted'
				});*/
				alert('Successfully Deleted !!');
				this.getData(this.paginationData.current_page);
			})
		})
	}

}
