import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { INgxMyDpOptions } from 'ngx-mydatepicker';

import { ApiService } from '../../../shared/service/api.service';
import { ShareService } from '../../../shared/service/share.service';
import { UtilService } from '../../../shared/service/util.service';
// import { NotifyService } from '../../../shared/service/notify.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

	id: any = "new";
	users: FormGroup;
	data: any;
	department: any;
	userlevel: any;
	formTouched: boolean = false;
	isProcessing: boolean = false;
	errors: any;

  constructor(
  		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		private utilService: UtilService,
		private shareService: ShareService,
		// private notifyService: NotifyService
	) { 
			this.users = fb.group({
			"id": [this.id, Validators.required],
			"department_id": ["", Validators.nullValidator],
			"userlevel_id": ["", Validators.nullValidator],
			"fullname": ["", Validators.required],
			"username": ["", [Validators.required, Validators.email]],
			"password": [""],
			"confirmpwd": [""],
			"mobile_2": [],
			"landline": [""],
			"address": [""],
			"pincode": [""],
			"is_active": ["Yes", Validators.required],
			"comments": [""],
		})
  	}

  	resetErrorMessages(){
		this.errors = {
			"id": [this.id, Validators.required],
			"department_id": ["", Validators.required],
			"userlevel_id": ["", Validators.required],
			"fullname": ["", Validators.required],
			"username": ["", Validators.required],
			"password": [""],
			"confirmpwd": [""],
			"mobile_2": [],
			"landline": [""],
			"address": [""],
			"pincode": [""],
			"is_active": ["", Validators.required],
			"comments": [""],
		}
	}

	cancel(){
		this.router.navigateByUrl('/users');
	}

	ngOnInit() {
		this.getDepartment();
		this.getUserlevels();
		this.route.params.subscribe(params => {
			if(params['id']=='new'){
				this.id="new";
			}else{
				this.id = +params['id']; // (+) converts string 'id' to a number
				this.getData(this.id);
			}
		});
	}

	getDepartment(){
		this.apiService.get("admin/department")
		.then(data => {
			let l_data: any = data;
			this.department = l_data.data;
		})
	}

	getUserlevels(){
		this.apiService.get("admin/userlevels")
		.then(data => {
			let l_data: any = data;
			this.userlevel = l_data.data;
		})
	}

	getData(id:any){
		this.apiService.get("admin/user_info/"+id)
		.then(data => { 
			let l_data: any = data;
			this.users.patchValue(l_data[0]);
		})
	}

	addOrUpdate(users){
		this.formTouched = true;
		if(users.invalid){
			return false;
		}
		this.resetErrorMessages();
		// console.log(users.value);
		if((this.users.value.password != '') || (this.users.value.confirmpwd != ''))
		{
			if(this.users.value.password != this.users.value.confirmpwd)
			{
				// this.notifyService.show({title: 'Errors', message: 'Please enter confirm password same as new passwod.'},'error');
			 	return false;
			 }
		}

		this.isProcessing = true;
		if(users.value.id == "new"){
			//post request
			this.apiService.post("admin/users",users.value)
			.then( data => {
				//success
				this.isProcessing = false;
				// this.notifyService.show({title: 'Success', message: 'User added successfully'});
				this.router.navigateByUrl('/users');
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
			})
		}else{
			//Put request

			this.apiService.put("admin/users/"+users.value.id,users.value)
			.then( data => {
				//success
				this.isProcessing = false;
				// this.notifyService.show({title: 'Success', message: 'User updated successfully'});
				this.router.navigateByUrl('/users');
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
				
			})
		}
	}



}
