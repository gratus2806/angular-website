import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomValidators } from 'ng2-validation';

import { AuthService } from '../shared/auth/auth.service';
import { ROLES } from '../shared/service/share.service';

@Component({
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  user: FormGroup;
  error: string;
  errors: any;
  isProcessing: boolean = false;
  constructor(fb: FormBuilder,
    private authService: AuthService,
    private router: Router) { 
    this.user = fb.group({
      "username": ["", Validators.compose([Validators.required,CustomValidators.email])],
      "password": ["", Validators.required],
    });
    this.errors = {
      "username": "",
      "password": ""
    };
  }  
  ngOnInit() {
  }

  login(user){
    this.errors = {
      "username": "",
      "password": ""
    };
    this.isProcessing = true;
    this.authService.login(user).then((data) => {
      this.isProcessing = false;
      let user: any=data;
      this.router.navigateByUrl('/dashboard');
    })
    .catch(error => {
      this.isProcessing = false;
      // this.errors = message.message;
      
      if(error.status_code == 422){
        this.errors = error.errors;
      }
      else{
        this.error = error.message;
      }

    });
  }
}