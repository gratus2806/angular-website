import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../shared/service/api.service';
// import { NotifyService } from '../shared/service/notify.service';
import { AuthService } from '../shared/auth/auth.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

  	id: any = "new";
	changepassword: FormGroup;
	formTouched: boolean = false;
	isProcessing: boolean = false;
	errors: any;
	constructor(
		private authService: AuthService,
		private apiService: ApiService,
		private route: ActivatedRoute,
		private router: Router,
		private fb: FormBuilder,
		// private notifyService: NotifyService
		
		) { 

		this.changepassword = fb.group({
			"old": ["", Validators.required],
			"password": ["", Validators.required],
			"password_confirmation": ["", Validators.required]
		})
		this.resetErrorMessages();
	}

	resetErrorMessages(){
		this.errors = {
			"old": [""],
			"password": [""],
			"password_confirmation": [""]
		}
	}

	ngOnInit() {
		//this.apiService.
	}

	addOrUpdate(changepassword){

		if((this.changepassword.value.old == this.changepassword.value.password) && (this.changepassword.value.old != '') && (this.changepassword.value.password != ''))
		{
			 
			 // this.notifyService.show({title: 'Errors', message: 'Old & New password should not same.'},'error');
			 return false;			 
		}
		if((this.changepassword.value.password_confirmation != this.changepassword.value.password) && (this.changepassword.value.password_confirmation != '') && (this.changepassword.value.password != ''))
		{
			// this.notifyService.show({title: 'Errors', message: 'Please enter confirm password same as new passwod.'},'error');
			 return false;
		}


		this.formTouched = true;
		if(changepassword.invalid){
			console.log(changepassword.value);
			return false;
		}

		this.resetErrorMessages();
		this.isProcessing = true;

			this.apiService.post("admin/changepwd",changepassword.value)
			.then( data => {

				let data1:any  = data;

				if(data1.data.status == 'success'){
					//success
					this.isProcessing = false;
					// this.notifyService.show({title: 'Success', message: data1.data.message});
				}
				else
				{
					this.isProcessing = false;
					// this.notifyService.show({title: 'Error', message: data1.data.message},'error');
					return;
				}
				
				
			})
			.catch( error => {
				this.isProcessing = false;
				if(typeof error.error.errors !== 'undefined')
					this.errors = error.error.errors;
				
			})
	}
	
}
