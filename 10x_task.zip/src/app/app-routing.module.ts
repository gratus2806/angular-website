import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';

import { FullLayoutComponent } from "./layouts/full/full-layout.component";
import { ContentLayoutComponent } from "./layouts/content/content-layout.component";

import { Full_ROUTES } from "./shared/routes/full-layout.routes";
import { CONTENT_ROUTES } from "./shared/routes/content-layout.routes";

import { AuthGuardService } from './shared/auth/auth-guard.service';
import { ROLES } from './shared/service/share.service';

const appRoutes: Routes = [
{
	path: '',
	redirectTo: 'dashboard',
	pathMatch: 'full',
},
{
	path: '',
	component: FullLayoutComponent,
	data: {
		title: 'Dashboard',
	},
	children: [
	{
		path: 'dashboard',
		loadChildren: './dashboard/dashboard.module#DashboardModule',
		canActivate: [AuthGuardService],
		data: {
		  	roles: [ROLES.SYSTEM, ROLES.ADMIN, ROLES.GENERAL_MANAGER, ROLES.DEPARTMENT_HEAD, ROLES.EMPLOYEE, ROLES.OFFICE_BOY]
		},
	},
	{
		path: 'change-password',
		loadChildren: './change-password/change-password.module#ChangePasswordModule',
		canActivate: [AuthGuardService],
		data: {
		roles: [ROLES.SYSTEM, ROLES.ADMIN, ROLES.GENERAL_MANAGER, ROLES.DEPARTMENT_HEAD, ROLES.EMPLOYEE, ROLES.OFFICE_BOY]
		}
	},
	{
		path: 'users',
		loadChildren: './pages/users/users.module#UsersModule',
		canActivate: [AuthGuardService],
		data: {
		roles: [ROLES.SYSTEM, ROLES.ADMIN, ROLES.GENERAL_MANAGER]
		}
	},
	{
		path: 'leavetype',
		loadChildren: './pages/leavetype/leavetype.module#LeavetypeModule',
		canActivate: [AuthGuardService],
		data: {
		roles: [ROLES.SYSTEM, ROLES.ADMIN, ROLES.GENERAL_MANAGER]
		}
	},
	{
		path: 'department',
		loadChildren: './pages/department/department.module#DepartmentModule',
		canActivate: [AuthGuardService],
		data: {
		roles: [ROLES.SYSTEM, ROLES.ADMIN, ROLES.GENERAL_MANAGER]
		}
	},
	{
		path: 'clients',
		loadChildren: './pages/client/client.module#ClientModule',
		canActivate: [AuthGuardService],
		data: {
		roles: [ROLES.SYSTEM, ROLES.ADMIN, ROLES.GENERAL_MANAGER, ROLES.DEPARTMENT_HEAD, ROLES.EMPLOYEE, ROLES.OFFICE_BOY]
		}
	},
	{
		path: 'task',
		loadChildren: './pages/task/task.module#TaskModule',
		canActivate: [AuthGuardService],
		data: {
		roles: [ROLES.SYSTEM, ROLES.ADMIN, ROLES.GENERAL_MANAGER, ROLES.DEPARTMENT_HEAD, ROLES.EMPLOYEE, ROLES.OFFICE_BOY]
		}
	},
	]
},
{
	path: 'login',
	component: ContentLayoutComponent,
	canActivate: [AuthGuardService],
	data: {
		title: 'Login',
		roles: [ROLES.GUEST]
	},
	children: [
	{
		path: '',
		loadChildren: './login/login.module#LoginModule',
	}
	]
},
{
	path: 'register',
	component: ContentLayoutComponent,
	canActivate: [AuthGuardService],
	data: {
		title: 'Register',
		roles: [ROLES.GUEST]
	},
	children: [
	{
		path: '',
		loadChildren: './register/register.module#RegisterModule',
	}
	]
},
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})

export class AppRoutingModule {

}
